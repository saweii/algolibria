/* Local C++ syntax colouring. No network requests; source text stays unchanged. */
(() => {
    'use strict';
    const escape = text => text.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const words = text => new Set(text.split(' '));
    const types = words('void bool char char8_t char16_t char32_t wchar_t short int long signed unsigned float double auto size_t ptrdiff_t streamsize int8_t int16_t int32_t int64_t uint8_t uint16_t uint32_t uint64_t');
    const keywords = words('alignas alignof asm break case catch class concept const consteval constexpr constinit const_cast continue co_await co_return co_yield decltype default delete do dynamic_cast else enum explicit export extern for friend goto if inline mutable namespace new noexcept operator private protected public register reinterpret_cast requires return sizeof static static_assert static_cast struct switch template this thread_local throw try typedef typeid typename union using virtual volatile while');
    const containers = words('string string_view vector array pair tuple queue priority_queue deque stack map multimap unordered_map set multiset unordered_set bitset optional variant numeric_limits function less greater');
    const literals = words('true false nullptr NULL');
    const streams = words('cin cout cerr clog endl ws std');
    // Comments and literals are consumed before identifiers and brackets.
    // Raw strings, escaped characters, suffixes, and digit separators are kept.
    const lexer = /\/\/[^\r\n]*|\/\*[\s\S]*?(?:\*\/|$)|(?:u8|u|U|L)?R"([^ ()\\\t\r\n]{0,16})\([\s\S]*?\)\1"|(?:u8|u|U|L)?"(?:\\[\s\S]|[^"\\])*"|(?:u8|u|U|L)?'(?:\\[\s\S]|[^'\\\r\n])+'|^[ \t]*#[ \t]*[A-Za-z_]\w*|\b(?:0[xX][\da-fA-F']+(?:\.[\da-fA-F']*)?(?:[pP][+-]?[\d']+)?|0[bB][01']+|\d[\d']*(?:\.[\d']*)?(?:[eE][+-]?[\d']+)?)(?:[uUlLfF]+)?\b|[A-Za-z_]\w*|[{}()[\]]|(?:<<=|>>=|<=>|->\*|::|->|\+\+|--|&&|\|\||==|!=|<=|>=|<<|>>|\+=|-=|\*=|\/=|%=|&=|\|=|\^=)|[+\-*\/%=<>!&|^~?:]|[;,\.]|\s+|[^\s]/gm;

    function highlight(source) {
        const tokens = [];
        lexer.lastIndex = 0;
        let match;
        while ((match = lexer.exec(source)) !== null) tokens.push({text:match[0], start:match.index});
        const next = index => {while (++index < tokens.length) if (!/^\s+$/.test(tokens[index].text)) return tokens[index].text;return '';};
        const brackets = [];
        const typeNames = new Set();
        let expectTypeName = false, directive = false, includeHeader = false;
        return tokens.map((token, index) => {
            const text = token.text;
            let kind = '';
            if (/^\s+$/.test(text)) {
                if (text.includes('\n')) {directive = false; includeHeader = false;}
                return escape(text);
            }
            if (text.startsWith('//') || text.startsWith('/*')) kind = 'comment';
            else if (/^[ \t]*#/.test(text)) {kind = 'preprocessor';directive = true;includeHeader = /\binclude$/.test(text);}
            else if (includeHeader) {
                kind = 'header';
                if (text === '>' || /^"/.test(text)) includeHeader = false;
            }
            else if (/^(?:(?:u8|u|U|L)?R?"|(?:u8|u|U|L)?')/.test(text)) kind = 'string';
            else if (/^\d/.test(text)) kind = 'number';
            else if (literals.has(text)) kind = 'constant';
            else if (types.has(text)) kind = 'type';
            else if (keywords.has(text)) {kind = 'keyword';if (/^(class|struct|enum|concept)$/.test(text)) expectTypeName = true;}
            else if (/^[A-Za-z_]\w*$/.test(text)) {
                if (expectTypeName) {typeNames.add(text);expectTypeName = false;kind = 'class';}
                else if (containers.has(text) || typeNames.has(text)) kind = 'class';
                else if (next(index) === '(') kind = 'function';
                else if (streams.has(text)) kind = 'builtin';
                else if (/^[A-Z][A-Z_\d]+$/.test(text)) kind = 'constant';
                else kind = 'variable';
            }
            else if (/^[{([]$/.test(text)) {
                const level = brackets.length % 3;
                brackets.push({text,level});kind = 'bracket-'+level;
            }
            else if (/^[})\]]$/.test(text)) {
                const opening = {')':'(',']':'[','}':'{'}[text];
                const last = brackets[brackets.length-1];
                if (last && last.text === opening) {brackets.pop();kind = 'bracket-'+last.level;}
                else kind = 'bracket-0';
            }
            else if (/^[;,\.]$/.test(text)) kind = 'punctuation';
            else kind = 'operator';
            return '<span class="cpp-'+kind+'">'+escape(text)+'</span>';
        }).join('');
    }

    function highlightBlocks(root = document) {
        root.querySelectorAll('pre code.language-cpp').forEach(code => {
            if (code.dataset.highlighted) return;
            const source = code.textContent;
            code.innerHTML = highlight(source);
            code.dataset.highlighted = 'true';
            code.parentElement.classList.add('cpp-editor');
            code.parentElement.setAttribute('tabindex','0');
            code.parentElement.setAttribute('aria-label','Программа на C++20. Область кода с горизонтальной прокруткой');
        });
    }
    window.CPPHighlighter = {highlight, highlightBlocks};
})();
