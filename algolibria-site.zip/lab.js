/* Algolibria: bounded, deterministic algorithm traces and an accessible player. */
window.LAB=(()=>{
 'use strict';
 const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const range=(a,b)=>Array.from({length:Math.max(0,b-a)},(_,i)=>a+i);
 const field=(key,label,value,type='text')=>({key,label,value,type});
 const arrayField=field('array','Массив · от 1 до 12 целых чисел','3 1 4 2 5');
 const spanFields=[field('left','Левая граница l',1,'number'),field('right','Правая граница r, не включая',4,'number')];
 const graphFields=weighted=>[field('n','Число вершин · от 1 до 8',6,'number'),field('edges',weighted?'Неориентированные рёбра: u v вес':'Неориентированные рёбра: u v',weighted?'1 2 7\n1 3 2\n3 2 1\n2 4 2\n3 5 4\n4 6 2\n5 6 1':'1 2\n1 3\n2 4\n3 4\n3 5\n5 6\n4 6','textarea')];
 const modes={
  prefix:{title:'Префиксные суммы',tag:'Массивы',step:19,desc:'Построй префиксы и вычти две границы.',cost:'O(n) подготовка · O(1) запрос',fields:[arrayField,...spanFields],code:['p[0] = 0','для i = 0..n−1: p[i+1] = p[i] + a[i]','ответ = p[r] − p[l]']},
  binary:{title:'Бинарный поиск',tag:'Массивы',step:24,desc:'Найди первую позицию со значением ≥ x.',cost:'O(log n) поиск',fields:[{...arrayField,value:'1 3 5 7 9 11 13'},field('target','Ищем первое значение ≥',8,'number')],code:['l = 0; r = n','пока l < r: m = floor((l+r)/2)','если a[m] < x: l = m+1','иначе: r = m','ответ = l (n, если подходящего нет)']},
  two:{title:'Два указателя',tag:'Массивы',step:22,desc:'Ищи пару и объясняй движение границ.',cost:'O(n) после сортировки',fields:[{...arrayField,value:'1 2 4 7 9'},field('target','Сумма пары',11,'number')],code:['l = 0; r = n−1','пока l < r: s = a[l] + a[r]','если s = target: вернуть пару','если s < target: увеличить l','иначе: уменьшить r']},
  insertion:{title:'Сортировка вставками',tag:'Сортировка',step:10,desc:'Держи ключ и сдвигай готовый префикс.',cost:'O(n²) время · O(1) доп. память',fields:[{...arrayField,value:'5 2 4 1 3'}],code:['для i = 1..n−1: key = a[i]','j = i−1','пока j ≥ 0 и a[j] > key:','  a[j+1] = a[j]; j−−','a[j+1] = key']},
  window:{title:'Скользящее окно',tag:'Массивы',step:23,desc:'Найди максимальную сумму окна длины k.',cost:'O(n) время · O(1) доп. память',fields:[{...arrayField,value:'2 -1 4 3 -2 5'},field('k','Длина окна k',3,'number')],code:['sum = сумма первых k элементов','best = sum','для r = k..n−1:','  sum = sum − a[r−k] + a[r]','  best = max(best, sum)']},
  bfs:{title:'BFS',tag:'Графы',step:54,desc:'Следи за очередью и слоями расстояний.',cost:'O(n+m) время',fields:[...graphFields(false),field('start','Стартовая вершина',1,'number')],code:['d[start] = 0; очередь = [start]','пока очередь не пуста: извлечь v','для каждого соседа to вершины v:','  если to не открыта: d[to] = d[v]+1','  добавить to в очередь']},
  dijkstra:{title:'Дейкстра',tag:'Графы',step:60,desc:'Выбирай минимальную оценку и расслабляй рёбра.',cost:'O(n²+m) · наглядный выбор без кучи',fields:[...graphFields(true),field('start','Стартовая вершина',1,'number')],code:['d[start] = 0, остальные ∞','выбрать неготовую v с минимальным d[v]','пометить v готовой','для каждого ребра (v,to,w):','  d[to] = min(d[to], d[v]+w)']},
  dsu:{title:'СНМ / DSU',tag:'Структуры',step:38,desc:'Объединяй компоненты и замечай лишние рёбра.',cost:'O(α(n)) амортизированно на операцию',fields:graphFields(false),code:['каждая вершина — отдельная компонента','для ребра (u,v): a = find(u), b = find(v)','если a = b: объединение не нужно','иначе: меньшую компоненту присоединить к большей','обновить размер и число компонент']},
  fenwick:{title:'Дерево Фенвика',tag:'Структуры',step:43,desc:'Построй дерево, измени элемент, запроси сумму.',cost:'O(log n) изменение / запрос',fields:[arrayField,field('position','Индекс изменяемого элемента',2,'number'),field('delta','Прибавить к элементу',5,'number'),...spanFields],code:['построить дерево прибавлениями a[i]','для add: i = position+1','  tree[i] += delta; i += lowbit(i)','prefix(r): sum += tree[r]; r −= lowbit(r)','ответ = prefix(r) − prefix(l)']}
 };
 function integer(value,label,min=-1000000,max=1000000){
  const s=String(value).trim();if(!/^-?\d+$/.test(s))throw Error(label+': нужно целое число.');
  const n=Number(s);if(!Number.isSafeInteger(n)||n<min||n>max)throw Error(label+`: допустимы значения от ${min} до ${max}.`);return n;
 }
 function parse(id,raw){
  const c={};
  if(raw.array!==undefined){
   const parts=String(raw.array).trim().split(/[\s,;]+/).filter(Boolean);
   if(parts.length<1||parts.length>12)throw Error('Введи от 1 до 12 чисел в массиве.');
   c.a=parts.map(x=>integer(x,'Элемент массива'));
   if(id==='binary'||id==='two')c.a.sort((a,b)=>a-b);
   if(['prefix','fenwick'].includes(id)){c.left=integer(raw.left,'l',0,c.a.length);c.right=integer(raw.right,'r',0,c.a.length);if(c.left>c.right)throw Error('Левая граница не должна быть больше правой.');}
   if(id==='binary'||id==='two')c.target=integer(raw.target,'Цель',-2000000,2000000);
   if(id==='window')c.k=integer(raw.k,'Длина окна',1,c.a.length);
   if(id==='fenwick'){c.position=integer(raw.position,'Индекс',0,c.a.length-1);c.delta=integer(raw.delta,'Прибавка');}
  }else{
   c.n=integer(raw.n,'Число вершин',1,8);c.edges=[];
   const lines=String(raw.edges).trim()?String(raw.edges).trim().split(/\n/).filter(s=>s.trim()):[];
   if(lines.length>16)throw Error('В этой демонстрации можно ввести не больше 16 рёбер.');
   lines.forEach((s,i)=>{const p=s.trim().split(/[\s,;]+/);if(p.length!==(id==='dijkstra'?3:2))throw Error(`Строка ${i+1}: введи ${id==='dijkstra'?'u v вес':'u v'}.`);const u=integer(p[0],'Номер вершины',1,c.n)-1,v=integer(p[1],'Номер вершины',1,c.n)-1;if(u===v)throw Error('Для наглядности в этой демонстрации вводи рёбра между разными вершинами.');c.edges.push({u,v,w:id==='dijkstra'?integer(p[2],'Вес',0,1000000):1,id:i});});
   if(id!=='dsu')c.start=integer(raw.start,'Старт',1,c.n)-1;
  }
  return c;
 }
 function build(id,raw){
  if(!modes[id])throw Error('Неизвестный алгоритм');
  const c=parse(id,raw),steps=[];let result,question,answer;
  const emit=(line,text,extra={})=>steps.push(JSON.parse(JSON.stringify({line,text,values:c.a,...extra})));
  if(id==='prefix'){
   const p=[0];emit(0,'Пустой префикс имеет сумму 0.',{memory:p,memoryName:'Префиксы p · p[i] = сумма первых i элементов'});
   c.a.forEach((x,i)=>{p.push(p[i]+x);emit(1,`p[${i+1}] = ${p[i]} + (${x}) = ${p[i+1]}.`,{active:[i],done:range(0,i),memory:p,memoryActive:[i+1],memoryName:'Префиксы p',metrics:{'Обработано':`${i+1} / ${c.a.length}`}});});
   result=p[c.right]-p[c.left];emit(2,`Сумма [${c.left}, ${c.right}) = p[${c.right}] − p[${c.left}] = ${result}. Правая граница не входит.`,{active:range(c.left,c.right),memory:p,memoryActive:[c.left,c.right],memoryName:'Вычитаем два префикса',result});question=`Чему равна сумма на [${c.left}, ${c.right})?`;answer=String(result);
  }else if(id==='binary'){
   let l=0,r=c.a.length,comparisons=0;
   emit(0,'Входные числа отсортированы. Индексы относятся к этой копии. Ищем первую подходящую позицию в полуинтервале [l,r).',{candidates:range(l,r),metrics:{l,r,'Сравнений':0}});
   while(l<r){const m=Math.floor((l+r)/2);++comparisons;emit(1,`m = floor((${l}+${r})/2) = ${m}; сравниваем ${c.a[m]} и ${c.target}.`,{active:[m],candidates:range(l,r),markers:{[m]:'m'},metrics:{l,r,'Сравнений':comparisons}});if(c.a[m]<c.target){l=m+1;emit(2,'Середина слишком мала: всё до неё включительно исключаем.',{candidates:range(l,r),metrics:{l,r,'Сравнений':comparisons}});}else{r=m;emit(3,'Середина подходит, но слева может быть более ранний ответ.',{candidates:range(l,r),metrics:{l,r,'Сравнений':comparisons}});}}
   result=l;emit(4,l===c.a.length?`Ответ n = ${l}: подходящего элемента нет.`:`l = r = ${l}. Первая подходящая позиция: ${l}, значение ${c.a[l]}.`,{active:l<c.a.length?[l]:[],result,metrics:{l,r,'Сравнений':comparisons}});question=`Каков индекс первого элемента ≥ ${c.target} в отсортированном массиве? Если такого нет, введи n.`;answer=String(result);
  }else if(id==='two'){
   let l=0,r=c.a.length-1,comparisons=0,pair=null;
   emit(0,'Входные числа отсортированы. Индексы относятся к этой копии; l и r должны быть разными.',{active:[l,r],markers:{[l]:'l',[r]:'r'}});
   while(l<r){const sum=c.a[l]+c.a[r];++comparisons;emit(1,`${c.a[l]} + ${c.a[r]} = ${sum}; цель ${c.target}.`,{active:[l,r],markers:{[l]:'l',[r]:'r'},metrics:{'Сумма':sum,'Сравнений':comparisons}});if(sum===c.target){pair=[l,r];break;}if(sum<c.target){++l;emit(3,'Сумма мала. С прежним левым элементом подходящей пары уже не будет.',{active:[l,r],markers:{[l]:'l',[r]:'r'}});}else{--r;emit(4,'Сумма велика. С прежним правым элементом подходящей пары уже не будет.',{active:[l,r],markers:{[l]:'l',[r]:'r'}});}}
   result=pair;emit(pair?2:1,pair?`Пара найдена: индексы ${pair[0]} и ${pair[1]} в отсортированном массиве.`:'Указатели встретились. Пары из двух разных позиций нет.',{active:pair||[],result:pair?c.a[pair[0]]+' + '+c.a[pair[1]]:'Пары нет'});question=`Есть ли пара разных позиций с суммой ${c.target}? Введи да или нет.`;answer=pair?'да':'нет';
  }else if(id==='insertion'){
   const a=c.a.slice();let comparisons=0,shifts=0;emit(0,'Первый элемент сам образует отсортированный префикс.',{values:a,done:[0]});
   for(let i=1;i<a.length;++i){const key=a[i];let j=i-1;a[i]=null;emit(0,`Берём ключ ${key}. Пустая ячейка показывает место, которое нужно заполнить.`,{values:a,active:[i],done:range(0,i),metrics:{'Ключ':key,'Сдвигов':shifts}});while(j>=0){++comparisons;emit(2,`Сравниваем ${a[j]} с ключом ${key}.`,{values:a,active:[j,j+1],metrics:{'Ключ':key,'Сравнений':comparisons,'Сдвигов':shifts}});if(a[j]<=key)break;a[j+1]=a[j];a[j]=null;++shifts;emit(3,'Элемент больше ключа: сдвигаем его вправо, освобождая место.',{values:a,active:[j,j+1],metrics:{'Ключ':key,'Сдвигов':shifts}});--j;}a[j+1]=key;emit(4,`Ставим ключ ${key} в позицию ${j+1}. Префикс снова отсортирован.`,{values:a,active:[j+1],done:range(0,i+1),metrics:{'Сравнений':comparisons,'Сдвигов':shifts}});}
   result=a;emit(4,'Все элементы включены в отсортированный префикс.',{values:a,done:range(0,a.length),result:a.join(' ')});question='Каким будет отсортированный массив?';answer=a.join(' ');
  }else if(id==='window'){
   let sum=0;for(let i=0;i<c.k;++i){sum+=c.a[i];emit(0,`Добавляем a[${i}] = ${c.a[i]} в первое окно.`,{active:range(0,i+1),metrics:{'Текущая сумма':sum}});}let best=sum,bestLeft=0;emit(1,'Первое полное окно — начальный лучший ответ.',{active:range(0,c.k),metrics:{'Сумма':sum,'Максимум':best}});
   for(let r=c.k;r<c.a.length;++r){const left=r-c.k;sum=sum-c.a[left]+c.a[r];emit(3,`Убираем ${c.a[left]} слева и добавляем ${c.a[r]} справа: сумма ${sum}.`,{active:range(left+1,r+1),markers:{[left]:'ушёл',[r]:'пришёл'},metrics:{'Сумма':sum,'Максимум до сравнения':best}});if(sum>best){best=sum;bestLeft=left+1;}emit(4,'Сравниваем новое окно с лучшим. При равенстве сохраняем первое.',{active:range(left+1,r+1),metrics:{'Сумма':sum,'Максимум':best}});}
   result=best;emit(4,`Максимальная сумма ${best}, первое лучшее окно [${bestLeft}, ${bestLeft+c.k}).`,{active:range(bestLeft,bestLeft+c.k),result:best});question=`Чему равна максимальная сумма окна длины ${c.k}?`;answer=String(best);
  }else if(id==='fenwick'){
   const a=c.a.slice(),tree=Array(a.length+1).fill(0);const state=(extra={})=>({values:a,memory:tree.slice(1),memoryOffset:1,memoryName:'tree[i] · покрывает [i−lowbit(i), i)',...extra});
   emit(0,'Дерево изначально нулевое. Элементы массива нумеруются с 0, узлы дерева — с 1.',state());
   for(let p=0;p<a.length;++p)for(let i=p+1;i<=a.length;i+=i&-i){tree[i]+=a[p];emit(0,`Строим: a[${p}] = ${a[p]} входит в tree[${i}], покрывающий [${i-(i&-i)}, ${i}).`,state({active:[p],memoryActive:[i-1]}));}
   a[c.position]+=c.delta;emit(1,`Прибавляем ${c.delta} к a[${c.position}]. Начинаем с узла ${c.position+1}.`,state({active:[c.position]}));
   for(let i=c.position+1;i<=a.length;i+=i&-i){tree[i]+=c.delta;emit(2,`tree[${i}] += ${c.delta}. Следующий узел: ${i+(i&-i)}.`,state({active:[c.position],memoryActive:[i-1]}));}
   const prefix=end=>{let sum=0;for(let i=end;i>0;i-=i&-i){sum+=tree[i];emit(3,`prefix(${end}): прибавляем tree[${i}] = ${tree[i]}, накоплено ${sum}.`,state({memoryActive:[i-1],metrics:{'Префикс до':end,'Накоплено':sum}}));}return sum;};
   const right=prefix(c.right),left=prefix(c.left);result=right-left;emit(4,`После изменения сумма [${c.left}, ${c.right}) = ${right} − ${left} = ${result}.`,state({active:range(c.left,c.right),result}));question=`Какова сумма [${c.left}, ${c.right}) после прибавления ${c.delta} к позиции ${c.position}?`;answer=String(result);
  }else{
   const graph={n:c.n,edges:c.edges},adj=Array.from({length:c.n},()=>[]);
   c.edges.forEach(e=>{adj[e.u].push({to:e.v,w:e.w,id:e.id});adj[e.v].push({to:e.u,w:e.w,id:e.id});});
   if(id==='dsu'){
    const parent=range(0,c.n),size=Array(c.n).fill(1);let components=c.n;
    const find=v=>{while(v!==parent[v]){parent[v]=parent[parent[v]];v=parent[v];}return v;};
    const state=extra=>({graph,groups:range(0,c.n).map(find),memory:parent.map(x=>x+1),memoryOffset:1,memoryName:'Родитель каждой вершины',metrics:{'Компонент':components},...extra});
    emit(0,'Каждая вершина — отдельная компонента.',state({}));
    for(const e of c.edges){let a=find(e.u),b=find(e.v);emit(1,`Ребро ${e.u+1}—${e.v+1}: корни ${a+1} и ${b+1}.`,state({edge:e.id,active:[e.u,e.v]}));if(a===b){emit(2,'Корни совпали: вершины уже связаны, объединять нечего.',state({edge:e.id,active:[e.u,e.v]}));continue;}if(size[a]<size[b])[a,b]=[b,a];parent[b]=a;size[a]+=size[b];--components;emit(4,`Корень ${b+1} присоединяем к ${a+1}. Размер новой компоненты ${size[a]}.`,state({edge:e.id,active:[e.u,e.v]}));}
    result=components;emit(4,`Все рёбра обработаны. Осталось компонент: ${components}.`,state({result}));question='Сколько компонент останется после всех объединений?';answer=String(result);
   }else{
    const dist=Array(c.n).fill(null),visited=[],settled=new Set();dist[c.start]=0;const queue=id==='bfs'?[c.start]:[];let relaxations=0;
    const state=extra=>({graph,dist,done:visited,...(id==='bfs'?{queue}:{}),metrics:{'Обработано':visited.length,'Улучшений':relaxations},...extra});
    emit(0,`Старт ${c.start+1}: расстояние 0. Остальные вершины пока недостижимы.`,state({active:[c.start]}));
    if(id==='bfs'){
     while(queue.length){const v=queue.shift();visited.push(v);emit(1,`Извлекаем ${v+1} из начала очереди.`,state({active:[v]}));for(const e of adj[v]){if(dist[e.to]!==null)continue;dist[e.to]=dist[v]+1;queue.push(e.to);++relaxations;emit(4,`Первое открытие ${e.to+1}: d = ${dist[v]} + 1 = ${dist[e.to]}. Сразу отмечаем и ставим в очередь.`,state({active:[v,e.to],edge:e.id}));}}
    }else{
     for(let turn=0;turn<c.n;++turn){let v=-1;for(let i=0;i<c.n;++i)if(!settled.has(i)&&dist[i]!==null&&(v===-1||dist[i]<dist[v]))v=i;if(v===-1)break;visited.push(v);settled.add(v);emit(2,`Минимальная неготовая оценка у ${v+1}: ${dist[v]}. При неотрицательных весах она окончательна.`,state({active:[v]}));for(const e of adj[v]){if(settled.has(e.to))continue;const candidate=dist[v]+e.w;const improves=dist[e.to]===null||candidate<dist[e.to];if(improves){dist[e.to]=candidate;++relaxations;}emit(4,improves?`Релаксация ${v+1}→${e.to+1}: ${dist[v]} + ${e.w} = ${candidate}, улучшаем оценку.`:`Релаксация ${v+1}→${e.to+1}: кандидат ${candidate} не улучшает ${dist[e.to]}.`,state({active:[v,e.to],edge:e.id}));}}
    }
    result=dist.slice();emit(id==='bfs'?1:2,'Готово. ∞ обозначает вершины без пути из старта.',state({result:dist.map(x=>x===null?'∞':x).join(' · ')}));question=id==='bfs'?`Сколько вершин достижимо из ${c.start+1}, включая старт?`:`Каково расстояние из ${c.start+1} до ${c.n}? Если пути нет, введи −1.`;answer=String(id==='bfs'?dist.filter(x=>x!==null).length:(dist[c.n-1]??-1));
   }
  }
  return {steps,result,question,answer,config:c};
 }
 let mode='prefix',trace=null,index=0,timer=null,playing=false,speed=850,keyHandler=null,restoring=false;
 const saved={};const $=s=>document.querySelector(s);
 function defaults(id){return Object.fromEntries(modes[id].fields.map(f=>[f.key,String(f.value)]));}
 const knownMode=id=>Object.prototype.hasOwnProperty.call(modes,id);
 function linkHash(id,raw=defaults(id),step=1){
  if(!knownMode(id)||!Number.isInteger(step)||step<1)throw Error('Некорректный пример для ссылки.');
  const params=new URLSearchParams({sim:id,v:'1'});
  for(const f of modes[id].fields)params.set(f.key,String(raw[f.key]));
  params.set('step',String(step));return '#lab?'+params.toString();
 }
 function readLink(hash){
  const fallback=(id,message)=>({id,raw:defaults(id),step:1,message});
  if(!hash.includes('?'))return null;
  if(hash.length>8192)return fallback('prefix','Ссылка слишком длинная. Открыт стандартный пример префиксных сумм.');
  const params=new URLSearchParams(hash.slice(hash.indexOf('?')+1)),id=params.get('sim')||'prefix';
  if(!knownMode(id))return fallback('prefix','Симулятор из ссылки не найден. Выбери алгоритм или открой стандартный пример ниже.');
  const keys=['sim','v','step',...modes[id].fields.map(f=>f.key)];
  if(keys.some(key=>params.getAll(key).length>1))return fallback(id,'В ссылке повторяются параметры. Открыт стандартный пример выбранного алгоритма.');
  if(params.has('v')&&params.get('v')!=='1')return fallback(id,'Версия ссылки пока не поддерживается. Открыт стандартный пример выбранного алгоритма.');
  const raw=defaults(id);for(const f of modes[id].fields)if(params.has(f.key))raw[f.key]=params.get(f.key);
  let linkedTrace;try{linkedTrace=build(id,raw);}catch(e){return fallback(id,'Не удалось открыть данные из ссылки: '+e.message+' Открыт стандартный пример.');}
  let step=1,message='';
  if(params.has('step')){
   const value=params.get('step');
   if(!/^\d+$/.test(value)||!Number.isSafeInteger(Number(value))||Number(value)<1)message='Некорректный номер шага в ссылке. Пример открыт с первого шага.';
   else{step=Math.min(Number(value),linkedTrace.steps.length);if(step!==Number(value))message='В ссылке указан шаг за пределами примера. Открыт последний доступный шаг.';}
  }
  return {id,raw,step,message};
 }
 function lessonLink(step){const entry=Object.entries(modes).find(([,m])=>m.step===step);return entry?'#lab?sim='+entry[0]:null;}
 function syncLink(){
  if(restoring||!trace||!window.location)return;
  const hash=linkHash(mode,saved[mode],index+1);
  if(window.location.hash!==hash)try{window.history.replaceState(window.history.state,'',hash);}catch{/* Sharing still works if this browser blocks address updates. */}
 }
 function linkNotice(message){$('#labLinkNotice').textContent=message;$('#labLinkNotice').hidden=!message;}
 function clearShare(){if($('#labShareStatus'))$('#labShareStatus').textContent='';if($('#labShareFallback'))$('#labShareFallback').hidden=true;}
 async function share(){
  stop();const status=$('#labShareStatus'),fallback=$('#labShareFallback'),input=$('#labShareUrl'),button=$('#labShare');
  const url=window.location.href.split('#')[0]+linkHash(mode,saved[mode],index+1);
  input.value=url;status.textContent='';fallback.hidden=true;button.disabled=true;
  try{await navigator.clipboard.writeText(url);if(status.isConnected)status.textContent='Ссылка на построенный пример и текущий шаг скопирована.';}
  catch{if(status.isConnected){status.textContent='Скопируй ссылку из поля ниже.';fallback.hidden=false;input.focus();input.select();}}
  finally{button.disabled=false;}
 }
 function markup(){return `<div class="eyebrow">ПОПРОБУЙ → ПРЕДСКАЖИ → ОБЪЯСНИ</div><h1>Лаборатория алгоритмов</h1><p class="muted lab-lead">Меняй данные, управляй выполнением и разбирай каждый переход. Девять симуляторов — от суммы массива до кратчайшего пути.</p><div class="lab-layout"><nav class="lab-gallery" aria-label="Симуляторы">${Object.entries(modes).map(([id,m])=>`<button class="lab-choice" data-lab="${id}" aria-pressed="${id===mode}"><span class="lab-choice-tag">${m.tag}</span><strong>${m.title}</strong><span class="lab-choice-desc">${m.desc}</span></button>`).join('')}</nav><section class="lab-workspace" aria-label="Рабочая область"><div class="lab-heading"><div><span class="badge" id="labCost"></span><h2 id="labTitle"></h2></div><select id="labMode" aria-label="Алгоритм">${Object.entries(modes).map(([id,m])=>`<option value="${id}">${m.title}</option>`).join('')}</select></div><p id="labLinkNotice" class="note small lab-link-notice" role="status" hidden></p><details class="lab-input-card"><summary>Свои данные</summary><form id="labData" novalidate><div id="labFields" class="lab-fields"></div><div class="actions"><button class="primary" type="submit">Построить шаги</button><button type="button" id="labRandom">Случайный пример</button></div><p id="labError" class="lab-error" role="alert"></p></form></details><div class="lab-player"><div id="stage"></div><div class="lab-controls"><button id="prev" aria-label="Предыдущий шаг">←</button><button class="primary" id="labPlay">▶ Воспроизвести</button><button id="next" aria-label="Следующий шаг">→</button><button id="labReset">Сначала</button><select id="labSpeed" aria-label="Скорость воспроизведения"><option value="1600">Медленно</option><option value="850" selected>Обычно</option><option value="350">Быстро</option></select></div><label class="lab-timeline">Шаг <output id="labCounter"></output><input id="labScrub" type="range" min="1" value="1" aria-label="Шаг алгоритма"></label><p class="small muted">← / → — по шагам, пробел — пауза. Горячие клавиши работают вне полей ввода.</p><div class="lab-share"><button id="labShare" type="button">Поделиться примером</button><p class="small muted">Ссылка сохранит построенный пример и текущий шаг.</p><p id="labShareStatus" class="small lab-share-status" role="status"></p><div id="labShareFallback" hidden><label class="lab-share-link" for="labShareUrl">Ссылка на пример<input id="labShareUrl" type="text" readonly spellcheck="false"></label></div></div></div><div class="lab-bottom"><section class="lab-pseudocode card"><h3>Что выполняется сейчас</h3><ol id="labCode"></ol><a id="labLesson" class="textlink">Разобрать теорию →</a><br><a id="labPractice" class="textlink lab-practice-link">Решить задачу →</a></section><details class="lab-challenge card"><summary>Сначала предскажи ответ</summary><p id="labQuestion" class="spacer"></p><form id="labQuiz"><label for="labAnswer">Твой прогноз</label><div class="inline"><input id="labAnswer" autocomplete="off" required><button>Проверить</button></div></form><p id="labFeedback" role="status" class="feedback"></p><details><summary>Показать ответ</summary><p id="labExpected"></p></details></details></div></section></div>`;}
 function stop(){playing=false;if(timer!==null)clearTimeout(timer);timer=null;if($('#labPlay'))$('#labPlay').textContent='▶ Воспроизвести';}
 function destroy(){stop();if(keyHandler&&typeof document!=='undefined')document.removeEventListener('keydown',keyHandler);keyHandler=null;}
 function fields(){const raw=saved[mode]||defaults(mode);$('#labFields').innerHTML=modes[mode].fields.map(f=>`<label for="lab-${f.key}" class="${f.type==='textarea'||f.key==='array'?'lab-field-wide':''}"><span>${f.label}</span>${f.type==='textarea'?`<textarea id="lab-${f.key}" name="${f.key}" rows="4" spellcheck="false">${escape(raw[f.key])}</textarea>`:`<input id="lab-${f.key}" name="${f.key}" type="${f.type}" value="${escape(raw[f.key])}" ${f.type==='number'?'step="1"':''}>`}</label>`).join('');}
 function rebuild(raw){stop();try{const next=build(mode,raw);trace=next;index=0;saved[mode]={...raw};$('#labError').textContent='';linkNotice('');clearShare();$('#labQuestion').textContent=trace.question;$('#labExpected').textContent=trace.answer;$('#labAnswer').value='';$('#labFeedback').textContent='';$('#labScrub').max=trace.steps.length;draw();return true;}catch(e){$('#labError').textContent=e.message+' Шаги предыдущего корректного примера сохранены.';return false;}}
 function choose(id){if(!knownMode(id))return;stop();mode=id;$('#labMode').value=id;$('#labTitle').textContent=modes[id].title;$('#labCost').textContent=modes[id].cost;document.querySelectorAll('[data-lab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.lab===id)));const lesson=window.ALG?.roadmap.find(r=>r.id===modes[id].step)?.lesson;$('#labLesson').href=lesson===undefined?'#lessons':'#lesson/'+lesson;$('#labPractice').href=window.PRACTICE_HUB?.labLink(id)||'#practice';fields();rebuild(saved[id]||defaults(id));}
 function cells(values,active=[],done=[],markers={},offset=0,candidates){return `<div class="lab-cells">${values.map((v,i)=>`<div class="lab-cell-wrap"><span class="lab-index">${i+offset}</span><span class="lab-cell ${active.includes(i)?'is-active':''} ${done.includes(i)?'is-done':''} ${candidates&&!candidates.includes(i)?'is-muted':''}">${v===null?'·':escape(v)}</span><span class="lab-marker">${escape(markers[i]||'')}</span></div>`).join('')}</div>`;}
 function graphEdge(s,e,points){
  const a=points[e.u],b=points[e.v],u=Math.min(e.u,e.v),v=Math.max(e.u,e.v);
  const parallel=s.graph.edges.filter(x=>Math.min(x.u,x.v)===u&&Math.max(x.u,x.v)===v);
  const rank=parallel.findIndex(x=>x.id===e.id),offset=(rank-(parallel.length-1)/2)*42;
  const p=points[u],q=points[v],length=Math.hypot(q.x-p.x,q.y-p.y),nx=-(q.y-p.y)/length,ny=(q.x-p.x)/length;
  const cx=(a.x+b.x)/2+nx*offset,cy=(a.y+b.y)/2+ny*offset;
  const tx=(a.x+b.x)/4+cx/2,ty=(a.y+b.y)/4+cy/2,width=Math.max(30,String(e.w).length*8+14);
  return `<g class="${s.edge===e.id?'edge-active':''}"><path d="M ${a.x} ${a.y} Q ${cx} ${cy} ${b.x} ${b.y}"/>${mode==='dijkstra'?`<rect x="${tx-width/2}" y="${ty-11}" width="${width}" height="22" rx="7"/><text x="${tx}" y="${ty+5}">${e.w}</text>`:''}</g>`;
 }
 function graph(s){const n=s.graph.n,points=range(0,n).map(i=>{const angle=-Math.PI/2+i*2*Math.PI/n;return {x:n===1?220:220+150*Math.cos(angle),y:n===1?155:155+112*Math.sin(angle)};});const colors=['#d6ef87','#91c8e6','#f1b883','#c8ace8','#f3aebc','#86d3bd','#e6d37b','#c7d2dd'];return `<svg class="lab-graph" viewBox="0 0 440 310" role="img" aria-label="Неориентированный граф. Состояние вершин также показано в таблице ниже.">${s.graph.edges.map(e=>graphEdge(s,e,points)).join('')}${points.map((p,i)=>`<g class="lab-node ${(s.active||[]).includes(i)?'node-active':''} ${(s.done||[]).includes(i)?'node-done':''}"><circle cx="${p.x}" cy="${p.y}" r="20" ${s.groups?`style="fill:${colors[s.groups[i]%colors.length]}"`:''}/><text x="${p.x}" y="${p.y+5}">${i+1}</text></g>`).join('')}</svg><div class="lab-node-table">${points.map((p,i)=>`<span><strong>${i+1}</strong><span>${s.dist?'d = '+(s.dist[i]===null?'∞':s.dist[i]):'комп. '+(s.groups[i]+1)}</span></span>`).join('')}</div>`;}
 function draw(){if(!trace||!$('#stage'))return;const s=trace.steps[index];$('#stage').innerHTML=`<div class="lab-stage lab-stage-new"><div class="lab-step-label">${escape(modes[mode].title)} · ШАГ ${index+1} / ${trace.steps.length}</div>${s.graph?graph(s):cells(s.values,s.active,s.done,s.markers,0,s.candidates)}${s.memory?`<div class="lab-memory"><div class="lab-step-label">${escape(s.memoryName||'Состояние')}</div>${cells(s.memory,s.memoryActive,[],{},s.memoryOffset||0)}</div>`:''}${s.queue?`<div class="lab-queue"><span>Очередь →</span>${s.queue.length?s.queue.map(v=>`<b>${v+1}</b>`).join(''):'<span>пусто</span>'}</div>`:''}<div class="lab-metrics">${Object.entries(s.metrics||{}).map(([k,v])=>`<span>${escape(k)} <strong>${escape(v)}</strong></span>`).join('')}</div><p class="step-text" aria-live="polite">${escape(s.text)}</p>${s.result!==undefined?`<div class="lab-result">Ответ <strong>${escape(s.result)}</strong></div>`:''}</div>`;$('#prev').disabled=index===0;$('#next').disabled=index===trace.steps.length-1;$('#labScrub').value=index+1;$('#labCounter').textContent=`${index+1} из ${trace.steps.length}`;$('#labCode').innerHTML=modes[mode].code.map((line,i)=>`<li class="${i===s.line?'current':''}" ${i===s.line?'aria-current="step"':''}>${escape(line)}</li>`).join('');clearShare();syncLink();}
 function move(delta){stop();index=Math.max(0,Math.min(trace.steps.length-1,index+delta));draw();}
 function schedule(){timer=setTimeout(()=>{if(!playing||!$('#stage'))return;if(index<trace.steps.length-1){++index;draw();}if(index===trace.steps.length-1)stop();else schedule();},speed);}
 function toggle(){if(playing){stop();return;}if(index===trace.steps.length-1)index=0;playing=true;$('#labPlay').textContent='Ⅱ Пауза';draw();schedule();}
 function randomExample(){
  const raw=defaults(mode),random=(lo,hi)=>lo+Math.floor(Math.random()*(hi-lo+1));
  if(raw.array!==undefined){const a=range(0,8).map(()=>random(-5,15));raw.array=a.join(' ');if(raw.left!==undefined){raw.left='1';raw.right='6';}if(mode==='window')raw.k=String(random(2,4));if(raw.target!==undefined)raw.target=String(mode==='binary'?random(-3,18):random(-5,25));if(mode==='fenwick'){raw.position=String(random(0,7));raw.delta=String(random(-5,8));}}
  else{raw.n='6';const edges=[];for(let i=1;i<6;++i)edges.push([i,i+1]);for(let i=1;i<=6;++i)for(let j=i+2;j<=6;++j)if(Math.random()<.23)edges.push([i,j]);raw.edges=edges.map(e=>e.join(' ')+(mode==='dijkstra'?' '+random(0,9):'')).join('\n');}
  saved[mode]=raw;fields();rebuild(raw);
 }
 function mount(){
  const linked=readLink(window.location.hash);restoring=true;
  try{if(linked){saved[linked.id]=linked.raw;choose(linked.id);index=linked.step-1;}else choose(mode);}finally{restoring=false;}
  draw();if(linked)linkNotice(linked.message);
  $('#labShare').onclick=share;
  $('#labMode').onchange=e=>choose(e.target.value);document.querySelectorAll('[data-lab]').forEach(b=>b.onclick=()=>choose(b.dataset.lab));$('#labData').onsubmit=e=>{e.preventDefault();rebuild(Object.fromEntries(new FormData(e.currentTarget)));};$('#labRandom').onclick=randomExample;$('#prev').onclick=()=>move(-1);$('#next').onclick=()=>move(1);$('#labReset').onclick=()=>{stop();index=0;draw();};$('#labScrub').oninput=e=>{stop();index=Number(e.target.value)-1;draw();};$('#labPlay').onclick=toggle;$('#labSpeed').value=String(speed);$('#labSpeed').onchange=e=>{speed=Number(e.target.value);if(playing){clearTimeout(timer);schedule();}};$('#labQuiz').onsubmit=e=>{e.preventDefault();const normalize=x=>x.trim().toLowerCase().replace(/[−–]/g,'-').replace(/[\s,;]+/g,' ');const ok=normalize($('#labAnswer').value)===normalize(trace.answer);$('#labFeedback').textContent=ok?'Верно! Теперь проследи, почему алгоритм получил этот ответ.':'Пока не совпало. Проверь данные и пройди ещё несколько шагов.';};keyHandler=e=>{if(e.altKey||e.ctrlKey||e.metaKey||['INPUT','TEXTAREA','SELECT','BUTTON','A','SUMMARY'].includes(e.target.tagName)||e.target.isContentEditable)return;if(e.key==='ArrowRight'){e.preventDefault();move(1);}else if(e.key==='ArrowLeft'){e.preventDefault();move(-1);}else if(e.key===' '){e.preventDefault();toggle();}};document.addEventListener('keydown',keyHandler);
 }
 return {markup,mount,destroy,build,modes,defaults,linkHash,readLink,lessonLink};
})();
